import java.awt.BorderLayout;

import javax.swing.JFrame;

public class Reversi extends JFrame {

	// TODO

}
